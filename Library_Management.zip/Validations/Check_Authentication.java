package Validations;

import DataBaseDao.Admin_Dao;
import java.util.regex.Pattern;

public class Check_Authentication extends Admin_Dao
{

    private static final String PASSWORD_REGEX = "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$";

    public boolean isPermitted(String uId, String pass, String cPass)
    {

        try
        {
            boolean isExist = isPermittedDao(uId, pass, cPass);

            if (isExist)
            {
                // User exists with the same credentials, return false
                return false;
            }

            // If the password is valid based on the regex return true
            return Pattern.matches(PASSWORD_REGEX, pass);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }
}
