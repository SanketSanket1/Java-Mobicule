package Validations;

import java.util.Scanner;

public class MobileValidation
{
    Scanner sc = new Scanner(System.in);

    public String checkMobileValidation(String mobile)
    {
        int i = 0, flag = 0;
        String res = null;

        if(mobile.length() == 10)
        {
            while (true)
            {
                while (i < mobile.length())
                {
                    char ch = mobile.charAt(i);
                    if (!Character.isDigit(ch)) {
                        flag = 0;
                        break;
                    }
                    i++;
                }
                if (i == mobile.length())
                {
                    flag = 1;
                }

                if (flag == 1)
                {
                    res = mobile;
                    break;
                }
                else
                {
                    System.out.println("Mobile Number Invalid Please Enter Valid Mobile Number\n");
                    System.out.println("Enter Valid Mobile Number : ");
                    System.out.println("=> ");
                    mobile = sc.next();
                    checkMobileValidation(mobile);
                }
            }
        }
        else
        {
            System.out.println("Please Give 10 Digit Number Number ");

            System.out.println("Enter Valid Mobile Number : ");
            System.out.println("=> ");
            mobile = sc.next();
            checkMobileValidation(mobile);
        }

        return res;
    }
}
