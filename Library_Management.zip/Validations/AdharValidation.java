package Validations;

import java.util.Scanner;

public class AdharValidation
{
    Scanner sc = new Scanner(System.in);

    public String checkAdharValidation(String adhar)
    {
        int i = 0, flag = 0;
        String res = null;

        if(adhar.length() == 12)
        {
            while (true)
            {
                while (i < adhar.length())
                {
                    char ch = adhar.charAt(i);

                    if (!Character.isDigit(ch)) {
                        flag = 0;
                        break;
                    }
                    i++;
                }
                if (i == adhar.length())
                {
                    flag = 1;
                }

                if (flag == 1)
                {
                    res = adhar;
                    break;
                }
                else
                {
                    System.out.println("Adhar Number Invalid Please Enter Valid Adhar Number\n");
                    System.out.println("Enter Valid Adhar Number : ");
                    adhar = sc.next();
                    checkAdharValidation(adhar);
                }
            }
        }
        else
        {
            System.out.println("Please Give 12 Digit Number Number ");

            System.out.println("Enter Valid Adhar Number : ");
            adhar = sc.next();
            checkAdharValidation(adhar);
        }

        return res;
    }
}
