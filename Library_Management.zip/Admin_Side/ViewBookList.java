package Admin_Side;

import Main.HomePage;

public class ViewBookList extends ShowBook
{
    public void viewBook(String role,String uId)
    {
        try
        {
            showBook();
            new HomePage().menu(role,uId);
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }
}
