package Admin_Side;

import DataBaseDao.Admin_Dao;
import Main.HomePage;
import Validations.NameValidation;

import java.sql.ResultSet;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Scanner;

public class IssueBook extends Admin_Dao
{
    public void issueNewBook(String role,String uId)
    {
        Scanner sc = new Scanner(System.in);

        new ShowBook().showBook();

        System.out.println("\n\nEnter Your UserId : ");
        System.out.print("=> ");
        String userId = sc.next();
        userId = new NameValidation().checkNameValidation(userId);

        System.out.println("\n\nEnter Book ISBN Number : ");
        System.out.print("=> ");
        int isbn = sc.nextInt();

        System.out.println("\n\nWhen You Return this Book (give date yyyy-mm-dd) : ");
        System.out.print("=> ");
        String rdate = sc.next();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

        try
        {
            //date formator
            LocalDate returnDate = LocalDate.parse(rdate, formatter);

            //check count of book for perticular id
            ResultSet rs = issueCountDao(userId);
            int count = 0;
            while (rs.next())
            {
                count = rs.getInt(1);
            }
            if(count <= 5)
            {
                // Call the single DAO method
                boolean isIssued = issueBookDao(userId, isbn, returnDate);

                if (isIssued)
                {
                    System.out.println("Book Issued Successfully");
                    new HomePage().menu(role,uId);
                } else
                {
                    System.out.println("Failed to issue book.");
                    new HomePage().menu(role,uId);
                }
            }
            else
            {
                System.out.println("Already Five Book Issue on This User Id (only 5 Books can issue on Single userID)");
                new HomePage().menu(role,uId);
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException(e);
        }
    }
}

