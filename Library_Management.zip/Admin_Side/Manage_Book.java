package Admin_Side;

import DataBaseDao.Admin_Dao;
import Main.HomePage;
import java.sql.*;
import java.util.Scanner;

public class Manage_Book
{
    Scanner sc = new Scanner(System.in);

    public void ascSortBookList(String role,String uId)
    {
        ResultSet rs = new Admin_Dao.Manage_BookDAO().getBooksSortedByName("ASC");

        System.out.printf("%-10s %-15s %-15s %-25s %-20s %-15s\n", "id", "ISBN Number", "Book Name", "Author Name", "No Of Pages", "Category");

        try
        {
            while (rs.next())
            {
                int id = rs.getInt(1);
                int isbn = rs.getInt(2);
                String bname = rs.getString(3);
                String Author = rs.getString(4);
                int no_of_page = rs.getInt(5);
                String Category = rs.getString(6);

                System.out.printf("%-10s %-15s %-15s %-25s %-20s %-15s\n", id, isbn, bname, Author, no_of_page, Category);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        new HomePage().menu(role,uId);
    }

    public void descSortBookList(String role,String uId)
    {
        ResultSet rs = new Admin_Dao.Manage_BookDAO().getBooksSortedByName("DESC");

        System.out.printf("%-10s %-15s %-15s %-25s %-20s %-15s\n", "id", "ISBN Number", "Book Name", "Author Name", "No Of Pages", "Category");

        try
        {
            while (rs.next())
            {
                int id = rs.getInt(1);
                int isbn = rs.getInt(2);
                String bname = rs.getString(3);
                String Author = rs.getString(4);
                int no_of_page = rs.getInt(5);
                String Category = rs.getString(6);

                System.out.printf("%-10s %-15s %-15s %-25s %-20s %-15s\n", id, isbn, bname, Author, no_of_page, Category);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }

        new HomePage().menu(role,uId);
    }

    public void countBook(String role,String uId)
    {
        int count = new Admin_Dao.Manage_BookDAO().getBookCount();
        System.out.println("Total Count of Books: " + count);
        new HomePage().menu(role,uId);
    }

    public void removeBookInfo(String role,String uId)
    {
        System.out.println("Enter ISBN Id: ");
        int isbn = sc.nextInt();

        boolean isDeleted = new Admin_Dao.Manage_BookDAO().deleteBookByISBN(isbn);
        if (isDeleted)
        {
            System.out.println("Record Deleted Successfully.");
        }
        else
        {
            System.out.println("Record not Deleted.");
        }

        new HomePage().menu(role,uId);
    }

    public void updateBookInfo(String role,String uId)
    {
        System.out.println("What do you want to update?");
        System.out.println("1 -> ISBN\n2 -> Book Name\n3 -> Author Name\n4 -> No of Pages\n5 -> Category of Book\n6 -> Book Quantity");
        System.out.println("Enter Your Choice: ");
        int choice = sc.nextInt();

        new ShowBook().showBook();

        System.out.println("Enter Book ID: ");
        int bookId = sc.nextInt();

        boolean isUpdated = false;

        switch (choice)
        {
            case 1:
                System.out.println("Enter ISBN: ");
                int isbn = sc.nextInt();
                isUpdated = new Admin_Dao.Manage_BookDAO().updateBookInfo(bookId, "isbn", String.valueOf(isbn));
                break;
            case 2:
                System.out.println("Enter Book Name: ");
                String bookName = sc.next();
                isUpdated = new Admin_Dao.Manage_BookDAO().updateBookInfo(bookId, "bname", bookName);
                break;
            case 3:
                System.out.println("Enter Author Name: ");
                String author = sc.next();
                isUpdated = new Admin_Dao.Manage_BookDAO().updateBookInfo(bookId, "author", author);
                break;
            case 4:
                System.out.println("Enter No of Pages: ");
                int pages = sc.nextInt();
                isUpdated = new Admin_Dao.Manage_BookDAO().updateBookInfo(bookId, "no_of_page", String.valueOf(pages));
                break;
            case 5:
                System.out.println("Enter Category: ");
                String category = sc.next();
                isUpdated = new Admin_Dao.Manage_BookDAO().updateBookInfo(bookId, "btype", category);
                break;
            case 6:
                System.out.println("Enter Book Quantity: ");
                int quantity = sc.nextInt();
                isUpdated = new Admin_Dao.Manage_BookDAO().updateBookQuantity(bookId, quantity);
                break;
            default:
                System.out.println("Invalid Choice.");
                break;
        }

        if (isUpdated)
        {
            System.out.println("Record Updated Successfully.");
        }
        else
        {
            System.out.println("Failed to update record.");
        }

        new HomePage().menu(role,uId);
    }

    public void insertBookInfo(String role,String uId)
    {
        System.out.println("Enter ISBN: ");
        int isbn = sc.nextInt();

        System.out.println("Enter Book Name: ");
        String bookName = sc.next();

        System.out.println("Enter Author Name: ");
        String author = sc.next();

        System.out.println("Enter No of Pages: ");
        int pages = sc.nextInt();

        System.out.println("Enter Book Category: ");
        String category = sc.next();

        boolean isInserted = new Admin_Dao.Manage_BookDAO().insertBook(isbn, bookName, author, pages, category);
        if (isInserted)
        {
            System.out.println("Book Inserted Successfully.");
        }
        else
        {
            System.out.println("Failed to insert book.");
        }
        new HomePage().menu(role,uId);
    }

    public void categoryBookInfo(String role,String uId)
    {
        ResultSet rs = new Admin_Dao.Manage_BookDAO().getDistinctCategories();
        System.out.println("Distinct Categories: ");
        try
        {
            while (rs.next())
            {
                String category = rs.getString(1);
                System.out.println(category);
            }
        }
        catch (SQLException e)
        {
            e.printStackTrace();
        }
        new HomePage().menu(role,uId);
    }
}
