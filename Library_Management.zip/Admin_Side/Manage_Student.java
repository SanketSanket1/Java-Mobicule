package Admin_Side;

import DataBaseDao.Admin_Dao;
import Main.HomePage;
import Validations.AdharValidation;
import Validations.EmailValidation;
import Validations.MobileValidation;
import Validations.NameValidation;
import java.sql.*;
import java.util.Scanner;

public class Manage_Student extends Admin_Dao.Manage_StudentDAO
{
    public Manage_Student() {
        Admin_Dao.Manage_StudentDAO studentDAO = new Admin_Dao.Manage_StudentDAO();
    }

    public void sortStudentListAsc(String role,String uId)
    {
        try
        {
            ResultSet rs = new Admin_Dao.Manage_StudentDAO().getAllStudentsAsc();
            printStudentList(rs);
            new HomePage().menu(role,uId);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while fetching student list", e);
        }
    }

    public void sortStudentListDesc(String role,String uId)
    {
        try
        {
            ResultSet rs = new Admin_Dao.Manage_StudentDAO().getAllStudentsDesc();
            printStudentList(rs);
            new HomePage().menu(role,uId);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while fetching student list", e);
        }
    }

    public void countStudents(String role,String uId)
    {
        try
        {
            int count = new Admin_Dao.Manage_StudentDAO().getStudentCount();
            System.out.println("Total Count of Students: " + count);
            new HomePage().menu(role,uId);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while counting students", e);
        }
    }

    public void removeStudent(String role,String uId)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter User Id: ");
        String userId = sc.next();
        userId = new NameValidation().checkNameValidation(userId);

        try
        {
            int result1 = new Admin_Dao.Manage_StudentDAO().deleteStudentByUserId(userId);
            int result2 = new Admin_Dao.Manage_StudentDAO().deleteStudentFromStudentTable(userId);

            if (result1 > 0 && result2 > 0)
            {
                System.out.println("Record Deleted Successfully.");
            }
            else
            {
                System.out.println("Record Not Deleted");
            }
            new HomePage().menu(role,uId);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while deleting student", e);
        }
    }

    public void updateStudentInfo(String role,String uId)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter user Id: ");
        String userId = sc.next();
        userId = new NameValidation().checkNameValidation(userId);

        System.out.println("What do you want to update?");
        System.out.println("1 -> First Name\n2 -> Last Name\n3 -> Email\n4 -> Mobile\n5 -> Adhar Number");
        System.out.print("Enter your choice: ");
        int choice = sc.nextInt();

        String field = "";
        String value = "";

        try
        {
            switch (choice)
            {
                case 1:
                    System.out.println("Enter First Name: ");
                    value = new NameValidation().checkNameValidation(sc.next());
                    field = "fname";
                    break;
                case 2:
                    System.out.println("Enter Last Name: ");
                    value = new NameValidation().checkNameValidation(sc.next());
                    field = "lname";
                    break;
                case 3:
                    System.out.println("Enter Email: ");
                    value = new EmailValidation().checkEmailValidation(sc.next());
                    field = "email";
                    break;
                case 4:
                    System.out.println("Enter Mobile: ");
                    value = new MobileValidation().checkMobileValidation(sc.next());
                    field = "mobile";
                    break;
                case 5:
                    System.out.println("Enter Adhar: ");
                    value = new AdharValidation().checkAdharValidation(sc.next());
                    field = "adhar";
                    break;
                default:
                    System.out.println("Invalid Choice");
                    new HomePage().menu(role,uId);
                    return;
            }

            int result = new Admin_Dao.Manage_StudentDAO().updateStudentInfo(userId, field, value);
            if (result > 0)
            {
                System.out.println("Record Updated Successfully");
            }
            else
            {
                System.out.println("Record Not Updated");
            }
            new HomePage().menu(role,uId);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while updating student info", e);
        }
    }

    public void insertStudentInfo(String role,String uId)
    {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter User Id: ");
        String userId = sc.next();
        userId = new NameValidation().checkNameValidation(userId);

        System.out.println("Enter First Name: ");
        String fname = new NameValidation().checkNameValidation(sc.next());

        System.out.println("Enter Last Name: ");
        String lname = new NameValidation().checkNameValidation(sc.next());

        System.out.println("Enter Email: ");
        String email = new EmailValidation().checkEmailValidation(sc.next());

        System.out.println("Enter Mobile: ");
        String mobile = new MobileValidation().checkMobileValidation(sc.next());

        System.out.println("Enter Adhar Number: ");
        String adhar = new AdharValidation().checkAdharValidation(sc.next());

        try
        {
            int result = new Admin_Dao.Manage_StudentDAO().insertStudent(userId, fname, lname, email, mobile, adhar);
            if (result > 0)
            {
                System.out.println("Record Inserted Successfully");
            }
            else
            {
                System.out.println("Record Not Inserted");
            }
            new HomePage().menu(role,uId);
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while inserting student info", e);
        }
    }

    private void printStudentList(ResultSet rs) throws SQLException
    {
        System.out.printf("%-10s %-15s %-15s %-25s %-20s %-15s\n", "id", "First Name", "Last Name", "Email", "Mobile", "Adhar Card");
        while (rs.next())
        {
            int id = rs.getInt(1);
            String fname = rs.getString(2);
            String lname = rs.getString(3);
            String email = rs.getString(4);
            String mobile = rs.getString(5);
            String adhar = rs.getString(6);
            System.out.printf("%-10s %-15s %-15s %-25s %-20s %-15s\n", id, fname, lname, email, mobile, adhar);
        }
    }
}

