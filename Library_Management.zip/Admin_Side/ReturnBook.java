package Admin_Side;

import DataBaseDao.Admin_Dao;
import DataBaseDao.Admin_Dao.BookReturnDAO;
import Main.HomePage;
import Validations.NameValidation;
import java.util.Scanner;

public class ReturnBook extends Admin_Dao.BookReturnDAO
{
    Scanner sc = new Scanner(System.in);

    public void returnBook(String role,String uId)
    {
        System.out.println("Enter User Name : ");
        String uName = sc.next();
        uName = new NameValidation().checkNameValidation(uName);

        // Step 1: Get issueId from DAO
        int issueId = new BookReturnDAO().getIssueIdByUserName(uName);
        if (issueId == -1)
        {
            System.out.println("No issue record found for this user.");
            return;
        }

        System.out.println("Enter Book Name : ");
        System.out.println("=> ");
        String bName = sc.next().trim();
        bName = new NameValidation().checkNameValidation(bName);

        // Step 2: Get book ID from DAO
        int bid = new BookReturnDAO().getBookDetailsByBookName(bName);
        if (bid == -1)
        {
            System.out.println("Book not found.");
            return;
        }

        // Step 3: Calculate fine based on due date
        int fineDays = new BookReturnDAO().calculateFine(issueId);
        double fine = fineDays > 0 ? fineDays * 5.0 : 0.0;

        // Step 4: Insert return record using DAO
        boolean isReturnInserted = new BookReturnDAO().insertReturnBookRecord(issueId, fine);
        if (isReturnInserted)
        {
            System.out.println("Fine is = " + fine);

            // Step 5: Update book status to 'Returned' using DAO
            boolean isStatusUpdated = new BookReturnDAO().updateBookStatusToReturned(issueId);

            // Step 6: Update book quantity using DAO
            boolean isQuantityUpdated = new BookReturnDAO().updateBookQuantity(bid);

            if (isStatusUpdated)
            {
                System.out.println("Book return successfully.");
                if (isQuantityUpdated)
                {
                    System.out.println("Book quantity updated successfully.");
                }
                else
                {
                    System.out.println("Problem occurred while updating book quantity.");
                }
            }
            else
            {
                System.out.println("Failed to update issued book status.");
            }
        }
        else
        {
            System.out.println("Failed to insert return record.");
        }

        new HomePage().menu(role,uId);
    }
}