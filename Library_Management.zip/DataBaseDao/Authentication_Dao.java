package DataBaseDao;

import java.sql.*;

public class Authentication_Dao
{
    static Connection connection;
    static Statement statement;
    static ResultSet resultSet;
    static PreparedStatement preparedStatement;


    //Additional_Info
    public int insertAdditionalInfo(String fName, String lName, String email, String mobile, String adhar, String uId) throws SQLException
    {
        connection = DB_Connection.getSQLConnection();
        String query = "INSERT INTO sanket_I1433_UserData (fname, lname, email, mobile, adhar, userId) VALUES(?,?,?,?,?,?)";
        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, fName);
        preparedStatement.setString(2, lName);
        preparedStatement.setString(3, email);
        preparedStatement.setString(4, mobile);
        preparedStatement.setString(5, adhar);
        preparedStatement.setString(6, uId);
        return preparedStatement.executeUpdate();
    }


    //Login
    public boolean validateLogin(String role, String uId, String password) throws SQLException
    {
        connection = DB_Connection.getSQLConnection();

        if(role.equals("admin"))
        {
            String query = "SELECT * FROM Sanket_I1433_Admin WHERE a_userId = ? AND a_pass = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, uId);
            preparedStatement.setString(2, password);

            resultSet = preparedStatement.executeQuery();
            return resultSet.next();  // If a record is found, the login is valid
        }
        if(role.equals("student"))
        {
            String query = "SELECT * FROM Sanket_I1433_Student WHERE userId = ? AND password = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, uId);
            preparedStatement.setString(2, password);

            resultSet = preparedStatement.executeQuery();
            return resultSet.next();  // If a record is found, the login is valid
        }
        return false;
    }


    //Signup
    public static class SignupDAO
    {
        public SignupDAO()
        {
            connection = DB_Connection.getSQLConnection();
        }

        // Check if the user already exists
        public boolean isUserExists(String uId) throws SQLException
        {
            String query = "SELECT userId FROM Sanket_I1433_student WHERE userId = ?";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, uId);
            resultSet = preparedStatement.executeQuery();
            return resultSet.next();  // If a record is found, the user exists
        }

        // Insert a new user
        public boolean insertUser(String uId, String pass, String cPass) throws SQLException
        {
            String query = "INSERT INTO Sanket_I1433_student (userId, password, confirmPass, created_time) VALUES (?, ?, ?, current_TimeStamp)";
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, uId);
            preparedStatement.setString(2, pass);
            preparedStatement.setString(3, cPass);

            int res = preparedStatement.executeUpdate();
            return res > 0;  // If the insert was successful
        }
    }
}
