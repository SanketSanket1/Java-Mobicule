package DataBaseDao;

import java.sql.*;

public class User_Dao
{
    Connection connection;
    PreparedStatement preparedStatement;


    //ListOfIssueBook
    public ResultSet getIssuedBooks(String uName) throws SQLException
    {
        connection = DB_Connection.getSQLConnection();
        String query = "SELECT b.bname, i.due_date, i.status " +
                "FROM Sanket_I1433_IssuedBook as i " +
                "INNER JOIN Sanket_I1433_Book as b ON i.book_id = b.id " +
                "WHERE i.student_id = (SELECT id FROM sanket_I1433_UserData as u WHERE u.userId = ?)";
        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, uName);
        return preparedStatement.executeQuery();
    }


    //ViewAllDue
    public ResultSet getDueBooks(String uName) throws SQLException
    {
        connection = DB_Connection.getSQLConnection();
        String query = "SELECT b.bname, i.due_date " +
                "FROM Sanket_I1433_IssuedBook as i " +
                "INNER JOIN Sanket_I1433_Book as b ON i.book_id = b.id " +
                "AND status = 'Issued' " +
                "AND current_TimeStamp >= due_date " +
                "WHERE i.student_id = (SELECT id FROM sanket_I1433_UserData as u WHERE u.userId = ?)";
        preparedStatement = connection.prepareStatement(query);
        preparedStatement.setString(1, uName);
        return preparedStatement.executeQuery();
    }
}
