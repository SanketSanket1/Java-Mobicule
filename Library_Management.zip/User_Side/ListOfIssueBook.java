package User_Side;

import Authentication.Login;
import DataBaseDao.Authentication_Dao;
import DataBaseDao.User_Dao;
import Main.HomePage;
import Validations.NameValidation;
import Validations.PasswordValidation;
import java.sql.*;
import java.util.Scanner;

public class ListOfIssueBook
{
    ResultSet rs;
    Scanner sc = new Scanner(System.in);

    // This method is unchanged, it's the same as the original ListOfIssueBook class.
    public void listIssueBook(String role,String uId)
    {

        try
        {
            // Call the DAO layer to fetch the list of issued books
            rs = new User_Dao().getIssuedBooks(uId);
            if(rs.next())
            {
                // Display the results
                System.out.printf("%-15s %-15s %-15s\n", "Book Name", "Due Date", "Status");
                System.out.println("-----------------------------------------");

                while (rs.next())
                {
                    String bName = rs.getString(1);
                    Date dueDate = rs.getDate(2);
                    String status = rs.getString(3);

                    System.out.printf("%-15s %-15s %-15s\n", bName, dueDate, status);
                }
                new HomePage().menu(role, uId);
            }
            else
            {
                System.out.println("---------------------------------------------------------------");
                System.out.println("No Any Book Issue From this UserId.");
                System.out.println("Press 0 to exit or 1 to continue :");
                System.out.print("=>");
                int exit = sc.nextInt();
                if (exit == 0)
                {
                    System.exit(1);
                }
                else
                {
                    new Login().userLogin(role);
                }
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }
}
