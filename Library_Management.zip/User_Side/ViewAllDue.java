package User_Side;

import Authentication.Login;
import DataBaseDao.User_Dao;
import Main.HomePage;
import java.sql.*;
import java.util.Scanner;


public class ViewAllDue
{

    ResultSet rs = null;
    Scanner sc = new Scanner(System.in);

    // Method to view all due books
    public void viewDue(String role,String uId)
    {
        try
        {
            // Call the DAO layer to fetch the list of issued books
            rs = new User_Dao().getDueBooks(uId);
            if(rs != null)
            {
                // Display the results
                System.out.printf("%-15s %-15s\n", "Book Name", "Due Date");
                System.out.println("-----------------------------------------");

                while (rs.next())
                {
                    String bName = rs.getString(1);
                    Date dueDate = rs.getDate(2);

                    System.out.printf("%-15s %-15s\n", bName, dueDate);
                }
                new HomePage().menu(role, uId);
            }
            else
            {
                System.out.println("---------------------------------------------------------------");
                System.out.println("No Any Book Issue From this UserId.");
                System.out.println("Press 0 to exit or 1 to continue :");
                System.out.print("=>");
                int exit = sc.nextInt();
                if (exit == 0)
                {
                    System.exit(1);
                }
                else
                {
                    new Login().userLogin(role);
                }
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException(e);
        }
    }
}
