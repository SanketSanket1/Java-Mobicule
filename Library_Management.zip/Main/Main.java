package Main;

import Authentication.Login;
import Authentication.Signup;
import Validations.IntInputValidation;

import java.util.Scanner;

public class Main
{
    public void initialMenu()
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("---------------------------------------------------------------");
        System.out.println("|                   LIBRARY MANAGEMENT SYSTEM                 |");
        System.out.println("---------------------------------------------------------------");

        System.out.println("1 -> SignUp\n2 -> Login\n3 -> Exit\n");
        System.out.println("---------------------------------------------------------------");

        int ch = new IntInputValidation().checkInt();
        System.out.println("---------------------------------------------------------------");

        switch (ch)
        {
            case 1:
                new Signup().register();
                break;
            case 2:

                new Login().constructLogin();
                break;
            case 3:
                System.exit(1);
                break;
            default:
                System.out.println("\n---------------------------------------------------------------");

                System.out.println("Invalid Choice Please Enter Valid Choice.");
                System.out.println("---------------------------------------------------------------");
                System.out.println("Enter 0 to Exit or 1 to Continue");

                int exit = new IntInputValidation().checkInt();

                if(exit == 1)
                {
                    new Main().initialMenu();
                }
                else
                {
                    System.exit(1);
                }
        }
    }

    public static void main(String[] args) {

        new Main().initialMenu();
    }
}
