package Main;

import Admin_Side.*;
import Authentication.Login;
import User_Side.ListOfIssueBook;
import User_Side.ViewAllDue;

import java.util.Scanner;

public class HomePage extends Login
{
    private String role,uId;

    public void menu(String role, String uId)
    {
        System.out.println("\n\n\n");
        System.out.println("---------------------------------------------------------------");
        System.out.println("|                                                             |");
        System.out.println("|      ##########     WELCOME TO HOME PAGE     ##########     |");
        System.out.println("|                                                             |");
        System.out.println("---------------------------------------------------------------\n\n");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~ADMIN MAIN MENU~~~~~~~~~~~~~~~~~~~~~~~~~\n\n");

        Scanner sc = new Scanner(System.in);

        if(role.equals("admin")) {
            System.out.println("Which operation of the following you want to perform :");
            System.out.println("---------------------------------------------------------------");
            System.out.println("1 -> Manage Student\n2 -> Manage Book\n3 -> View Student List\n4 -> View Book List\n5 -> View Defaulter\n6 -> Issue Book\n7 -> Return Book\n8 -> Exit\n");
            System.out.println("---------------------------------------------------------------");
            System.out.println("Enter Your Choice : ");
            System.out.print("=>");
            int ch = sc.nextInt();
            System.out.println("---------------------------------------------------------------");

            switch (ch) {
                case 1:
                    System.out.println("\nWhich operation of the following you want to perform :");
                    System.out.println("---------------------------------------------------------------");
                    System.out.println("1 -> Sort Student List\n2 -> Student Count\n3 -> Remove Student Info\n4 -> Update Student Info\n5 -> Insert new Student Record\n6 -> Goto Main Menu");
                    System.out.println("---------------------------------------------------------------");
                    System.out.println("Enter Your Choice : ");
                    ch = sc.nextInt();
                    System.out.println("---------------------------------------------------------------");

                    switch (ch)
                    {
                        case 1 :
                            System.out.println("\nWhich operation of the following you want to perform :");
                            System.out.println("---------------------------------------------------------------");
                            System.out.println("1 -> Ascending Order List\n2 -> Descending Order List");
                            System.out.println("---------------------------------------------------------------");
                            System.out.println("Enter Your Choice :");
                            System.out.println("=> ");
                            ch = sc.nextInt();
                            System.out.println("---------------------------------------------------------------");

                            switch (ch)
                            {
                                case 1:
                                    new Manage_Student().sortStudentListAsc(role,uId);
                                    break;
                                case 2:
                                    new Manage_Student().sortStudentListDesc(role,uId);
                                    break;
                                default:
                                    System.out.println("---------------------------------------------------------------");
                                    System.out.println("Invalid Choice");
                                    System.out.println("---------------------------------------------------------------");
                                    menu(role,uId);
                            }
                            break;
                        case 2:
                                new Manage_Student().countStudents(role,uId);
                                break;
                        case 3:
                            new Manage_Student().removeStudent(role,uId);
                            break;
                        case 4:
                            new Manage_Student().updateStudentInfo(role,uId);
                            break;
                        case 5:
                            new Manage_Student().insertStudentInfo(role,uId);
                            break;
                        case 6:
                            menu(role,uId)
                            ;
                            break;
                        default:
                            System.out.println("---------------------------------------------------------------");
                            System.out.println("                       Invalid Choice");
                            System.out.println("---------------------------------------------------------------");
                            menu(role,uId);
                    }
                    break;
                case 2:
                    System.out.println("\nWhich operation of the following you want to perform :");
                    System.out.println("---------------------------------------------------------------");
                    System.out.println("1 -> Sort Book List\n2 -> Book Count\n3 -> Remove Book Info\n4 -> Update Book Info\n5 -> Insert new Book Record\n6 -> view Available Category\n7 -> Goto Main Menu");
                    System.out.println("---------------------------------------------------------------");
                    System.out.println("Enter Your Choice : ");
                    System.out.println("=> ");
                    ch = sc.nextInt();
                    System.out.println("---------------------------------------------------------------");
                    switch (ch)
                    {
                        case 1:
                            System.out.println("\nWhich operation of the following you want to perform :");
                            System.out.println("---------------------------------------------------------------");
                            System.out.println("1 -> Ascending Order List\n2 -> Descending Order List");
                            System.out.println("---------------------------------------------------------------");
                            System.out.println("Enter Your Choice :");
                            System.out.println("=> ");
                            ch = sc.nextInt();
                            System.out.println("---------------------------------------------------------------");

                            switch (ch)
                            {
                                case 1:
                                    new Manage_Book().ascSortBookList(role,uId);
                                    break;
                                case 2:
                                    new Manage_Book().descSortBookList(role,uId);
                                    break;
                                default:
                                    System.out.println("---------------------------------------------------------------");
                                    System.out.println("Invalid Choice");
                                    System.out.println("---------------------------------------------------------------");
                                    menu(role,uId);
                            }
                            break;
                        case 2:
                            new Manage_Book().countBook(role,uId);
                            break;
                        case 3:
                            new Manage_Book().removeBookInfo(role,uId);
                            break;
                        case 4:
                            new Manage_Book().updateBookInfo(role,uId);
                            break;
                        case 5:
                            new Manage_Book().insertBookInfo(role,uId);
                            break;
                        case 6:
                            new Manage_Book().categoryBookInfo(role,uId);
                            break;
                        case 7:
                            menu(role,uId);
                            break;
                        default:
                            System.out.println("---------------------------------------------------------------");
                            System.out.println("                       Invalid Choice");
                            System.out.println("---------------------------------------------------------------");
                            menu(role,uId);

                    }
                    break;
                case 3:
                    new ViewStudentList().viewStudent(role,uId);
                    break;
                case 4:
                    new ViewBookList().viewBook(role,uId);
                    break;
                case 5:
                    new ViewDefaulter().viewDefaulterList(role,uId);
                    break;
                case 6:
                    new IssueBook().issueNewBook(role,uId);
                    break;
                case 7:
                    new ReturnBook().returnBook(role,uId);
                    break;
                case 8:
                    System.exit(1);
                    break;
                default:
                    System.out.println("---------------------------------------------------------------");
                    System.out.println("                               Invalid Choice");
                    System.out.println("---------------------------------------------------------------");
                    menu(role,uId);
            }
        }
        else
        {
            System.out.println("Which operation of the following you want to perform :");
            System.out.println("---------------------------------------------------------------");
            System.out.println("1 -> View Due Date \n2 -> List of Issued Book\n3 -> Exit\n");
            System.out.println("---------------------------------------------------------------");
            System.out.println("Enter Your Choice : ");
            System.out.print("=>");
            int ch = sc.nextInt();
            System.out.println("---------------------------------------------------------------");

            switch (ch) {
                case 1:
                    new ViewAllDue().viewDue(role,uId);
                    break;
                case 2:
                    new ListOfIssueBook().listIssueBook(role,uId);
                    break;
                case 3:
                    System.exit(1);
                    break;
                default:
                    System.out.println("---------------------------------------------------------------");
                    System.out.println("                               Invalid Choice");
                    System.out.println("---------------------------------------------------------------");
                    menu(role,uId);
            }
        }

    }
}