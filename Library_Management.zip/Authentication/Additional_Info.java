package Authentication;

import DataBaseDao.Authentication_Dao;
import Validations.AdharValidation;
import Validations.EmailValidation;
import Validations.MobileValidation;
import Validations.NameValidation;
import java.sql.SQLException;
import java.util.Scanner;

public class Additional_Info 
{
    public Additional_Info(String uId)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("********** Insert Additional Information **********");

        System.out.println("Enter Your First Name : ");
        String fName = sc.next();
        fName = new NameValidation().checkNameValidation(fName);

        System.out.println("Enter Your Last Name : ");
        String lName = sc.next();
        lName = new NameValidation().checkNameValidation(lName);

        System.out.println("Enter Email Id : ");
        String email = sc.next();
        email = new EmailValidation().checkEmailValidation(email);

        System.out.println("Enter Mobile Number : ");
        String mobile = sc.next();
        mobile = new MobileValidation().checkMobileValidation(mobile);

        System.out.println("Enter Adhar Card : ");
        String adhar = sc.next();
        adhar = new AdharValidation().checkAdharValidation(adhar);

        try
        {
            int res = new Authentication_Dao().insertAdditionalInfo(fName, lName, email, mobile, adhar, uId);
            if (res > 0)
            {
                System.out.println("Record Inserted Successfully\n");
            }
            else
            {
                System.out.println("Record not Inserted");
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while inserting additional info", e);
        }
    }
}
