package Authentication;

import DataBaseDao.Authentication_Dao;
import Validations.Check_Authentication;
import Validations.NameValidation;
import Validations.PasswordValidation;
import java.util.Scanner;

public class Signup
{
    public Signup()
    {
        Authentication_Dao.SignupDAO signupDAO = new Authentication_Dao.SignupDAO();
    }

    public void register()
    {
        Scanner sc = new Scanner(System.in);
        int flag = 0;

        // Input validation
        System.out.println("Enter User Id : ");
        String uId = sc.next();
        uId = new NameValidation().checkNameValidation(uId);

        System.out.println("Enter Password : ");
        System.out.println("=> ");
        String pass = sc.next();
        pass = new PasswordValidation().checkPasswordValidation(pass);

        System.out.println("ReEnter Same Password : ");
        String cPass = sc.next();

        if (!pass.equals(cPass))
        {
            System.out.println("Please Enter same Password in both Field");
            System.out.println("ReEnter Password Again :");
            cPass = sc.next();

            while (true)
            {
                if (!pass.equals(cPass))
                {
                    System.out.println("Please Enter same Password in both Field");
                    System.out.println("ReEnter Password Again :");
                    cPass = sc.next();
                }
                else
                {
                    break;
                }
            }
        }

        try
        {
            // Check if the user already exists
            if (new Authentication_Dao.SignupDAO().isUserExists(uId))
            {
                System.out.println("This User is Already Exist");
                System.out.println("Please Signup with a different User Id");
                System.out.println("press 0 to exit or 1 to Continue");
                int exit = sc.nextInt();
                if (exit == 0)
                {
                    System.exit(1);
                }
                else
                {
                    System.out.println("\nEnter All Details Again\n");
                    register();
                }
            }
            else
            {
                // Proceed with the signup
                System.out.println("Request sent to Admin Please Wait !!!");

                if (new Check_Authentication().isPermitted(uId, pass, cPass))
                {
                    new Additional_Info(uId);  // Insert additional information

                    if (new Authentication_Dao.SignupDAO().insertUser(uId, pass, cPass))
                    {
                        System.out.println("UserId and Password set Successfully.\n");
                        System.out.println("\n---------- Signup Done Successfully ----------\n");
                        System.out.println("===================================================");

                        System.out.println("Press 1 for Login or 0 for Exit");
                        int next = sc.nextInt();

                        if (next == 1)
                        {
                            new Login().constructLogin();
                        }
                        else
                        {
                            System.exit(1);
                        }
                    }
                    else
                    {
                        System.out.println("Some Problem Occurred.");
                    }
                }
            }
        }
        catch (Exception e)
        {
            throw new RuntimeException("Error during registration", e);
        }
    }
}
