package Authentication;

import DataBaseDao.Authentication_Dao;
import Main.HomePage;
import Validations.NameValidation;
import Validations.PasswordValidation;
import Validations.RoleValidation;
import java.sql.*;
import java.util.Scanner;

public class Login
{

    public void constructLogin()
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter Your Role (student/admin):");
        System.out.print("=>");
        String role = sc.next();

        role = role.toLowerCase();
        role = new RoleValidation().checkRoleValidation(role);

        userLogin(role);
    }

    public void userLogin(String role)
    {
        Scanner sc = new Scanner(System.in);

        System.out.println("Enter User Id : ");
        System.out.print("=>");
        String uId = sc.next();
        uId = new NameValidation().checkNameValidation(uId);

        System.out.println("Enter Password : ");
        System.out.print("=>");
        String pass = sc.next();
        pass = new PasswordValidation().checkPasswordValidation(pass);

        try
        {
            if (new Authentication_Dao().validateLogin(role, uId, pass))
            {
                System.out.println("          _________________________________");
                System.out.println("               Login Successfully Done     ");
                System.out.println("          _________________________________");
                new HomePage().menu(role,uId);
            }
            else
            {
                System.out.println("---------------------------------------------------------------");
                System.out.println("Invalid User Name and Password");
                System.out.println("press 0 to exit or 1 to continue :");
                System.out.print("=>");
                int exit = sc.nextInt();
                if (exit == 0)
                {
                    System.exit(1);
                }
                else
                {
                    System.out.println("\nEnter User Id and Password Again\n");
                    userLogin(role);
                }
            }
        }
        catch (SQLException e)
        {
            throw new RuntimeException("Error while validating login", e);
        }
    }
}
